"""interfaces/modo_voz.py
Interfaz de voz interactiva en tiempo real para JESSYCA con soporte de Sesión Continua (Fase 51)
y Motor de Captura Calibrada con Diagnósticos y Telemetría (Fase 51.1).

Captura audio desde el micrófono con pre-roll/post-roll e histeresis VAD, transcribe a texto en español,
procesa la orden con el Agente Local Unificado en múltiples turnos sin repetir wake word,
y responde con síntesis de voz (TTS) y feedback visual diferenciado.

Ejecutar con:
    python -m interfaces.modo_voz
"""

from __future__ import annotations

import os
import re
import sys
import threading
import time
from dataclasses import dataclass
from typing import Any

# Asegurar encoding UTF-8 en consola Windows
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from config.manager import get_settings
from core.local_agent.local_agent import JessycaLocalAgent
from core.local_agent.local_agent_models import InputModality, JessycaRequest
from core.logger import get_logger
from core.state import StateMachine
from core.state.states import SessionState
from services.voice.audio_capture import CalibratedVoiceCaptureEngine
from services.voice.audio_device_manager import (
    SignalValidationStatus,
    get_audio_device_manager,
)
from services.voice.barge_in_controller import BargeInController
from services.voice.continuous_voice_session import (
    ContinuousVoiceSession,
    VoiceSessionMode,
)
from services.voice.device_resolver import VoiceDeviceResolver
from services.voice.stt_event_adapter import STTEventAdapter
from services.voice.stt_service import get_stt_service
from services.voice.spoken_text import prepare_spoken_text
from services.voice.tts_provider import get_tts_manager
from services.voice.voice_errors import VoiceCancelledError, VoiceInterruptedError
from services.voice.voice_diagnostics import (
    UtteranceLatencyTrace,
    VoiceDiscardReason,
)

logger = get_logger("jessyca.interfaces.modo_voz")

BANNER_VOZ = r"""
  +===============================================================+
  |              J E S S Y C A   3 . 0  —  MODO VOZ               |
  |         Sesión Conversacional Continua (Fase 51 / 51.1)       |
  |                                                               |
  |   * Activa con: "Jessica, [tu orden]"                         |
  |   * Luego habla directamente sin repetir "Jessica"            |
  |   * Di "adios", "salir" o presiona Ctrl+C para finalizar.     |
  +===============================================================+
"""

BANNER_PTT = r"""
  +===============================================================+
  |              J E S S Y C A   3 . 0  —  PULSAR PARA HABLAR     |
  |             Flujo de Voz Bajo Demanda (Prompt 08 / PTT)       |
  |                                                               |
  |   * Presiona ENTER para activar el micrófono y hablar         |
  |   * Transcripción local y envío al Core unificado             |
  |   * Sin escucha permanente en segundo plano                   |
  |   * Di "adios", "salir" o presiona Ctrl+C para finalizar.     |
  +===============================================================+
"""


@dataclass
class VoiceSpeakerMetrics:
    """Métricas de síntesis y reproducción de voz."""

    startup_latency_ms: float = 0.0
    duration_ms: float = 0.0
    engine_used: str = "edge_tts"
    voice_name: str = "es-PE-CamilaNeural"


class VoiceSpeaker:
    """Motor de síntesis de voz neuronal (Edge-TTS con es-PE-CamilaNeural) con fallback robusto."""

    def __init__(self, default_voice: str | None = None, barge_in_controller: Any | None = None) -> None:
        self._lock = threading.Lock()
        settings = get_settings()
        self.voice_name = default_voice or getattr(settings, "VOICE_DEFAULT_VOICE", "es-PE-CamilaNeural")
        self._sapi_speaker: Any = None
        self._sapi_voice_id: str | None = None
        self._pygame_ready = False
        self._tts_manager = get_tts_manager()
        self.barge_in_controller = barge_in_controller
        self.aurora_bridge: Any | None = None
        self._init_audio_system()

    def _init_audio_system(self) -> None:
        """Inicializa el subsistema de audio y mixer una sola vez para evitar overhead."""
        try:
            import pygame
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=24000, size=-16, channels=1, buffer=1024)
            self._pygame_ready = True
        except Exception as e:
            logger.debug(f"[VOICE TTS] Info al inicializar pygame.mixer: {e}")
            self._pygame_ready = False

    def _get_sapi_speaker(self) -> Any:
        """Inicializa perezosamente y de forma persistente el fallback SAPI."""
        if self._sapi_speaker is not None:
            return self._sapi_speaker
        try:
            import pythoncom
            import win32com.client

            pythoncom.CoInitialize()
            sp = win32com.client.Dispatch("SAPI.SpVoice")
            voices = sp.GetVoices()
            for i in range(voices.Count):
                v = voices.Item(i)
                desc = v.GetDescription().lower()
                if "sabina" in desc or "spanish" in desc or "español" in desc or "mexico" in desc or "spain" in desc:
                    sp.Voice = v
                    self._sapi_voice_id = v.Id
                    break
            sp.Rate = 1
            sp.Volume = 100
            self._sapi_speaker = sp
            return self._sapi_speaker
        except Exception as e:
            logger.debug(f"[VOICE TTS] SAPI fallback no disponible: {e}")
            return None

    def stop(self) -> None:
        """Detiene de inmediato cualquier reproducción o generación activa de voz."""
        # Playback owns this lock while speaking. Cancel before waiting for it,
        # otherwise an interruption cannot reach the running synthesis.
        current_token = getattr(self, "_current_token", None)
        if current_token:
            current_token.cancel()
        if self._tts_manager:
            self._tts_manager.cancel(reason="speaker_stopped")
        with self._lock:
            self._current_token = None
            try:
                import pygame

                if pygame.mixer.get_init():
                    pygame.mixer.stop()
            except Exception:
                pass
            if self._sapi_speaker:
                try:
                    self._sapi_speaker.Speak("", 2)  # SVSFPurgeBeforeSpeak
                except Exception:
                    pass
            if hasattr(self, "aurora_bridge") and self.aurora_bridge:
                try:
                    self.aurora_bridge.notify_tts_end(interrupted=True)
                except Exception:
                    pass

    def speak(
        self,
        text: str,
        session_id: str | None = None,
        capture_engine: Any | None = None,
    ) -> VoiceSpeakerMetrics:
        """Sintetiza y reproduce el texto mediante TTSManager entregando por frases completas para fluidez."""
        if not text or not text.strip():
            return VoiceSpeakerMetrics()

        clean_text = prepare_spoken_text(text)
        if not clean_text:
            return VoiceSpeakerMetrics()
        metrics = VoiceSpeakerMetrics(voice_name=str(self.voice_name))
        t_start = time.perf_counter()

        from core.cancellation import CancellationToken

        token = CancellationToken()
        self._current_token = token

        if self.barge_in_controller:
            self.barge_in_controller.notify_tts_started(cancellation_token=token, session_id=session_id)

        if hasattr(self, "aurora_bridge") and self.aurora_bridge:
            try:
                self.aurora_bridge.notify_tts_start(clean_text)
            except Exception:
                pass

        try:
            # Dividir en frases completas para reducir TTFA (Time to First Audio) y permitir corte inmediato
            sentences = [clean_text] if len(clean_text) <= 280 else [
                s.strip() for s in re.split(r"(?<=[.!?])\s+", clean_text) if s.strip()
            ]
            if not sentences:
                sentences = [clean_text]

            total_duration_ms = 0.0
            first_sentence = True

            def _run_playback() -> None:
                nonlocal total_duration_ms, first_sentence
                with self._lock:
                    for sentence in sentences:
                        if token.is_cancelled:
                            logger.info("[VOICE SPEAKER] Reproducción interrumpida entre frases.")
                            break

                        try:
                            success, tts_met = self._tts_manager.speak(
                                sentence,
                                voice=str(self.voice_name),
                                cancellation_token=token,
                            )
                            if success:
                                if first_sentence:
                                    metrics.startup_latency_ms = tts_met.t2_first_audio_ms or ((time.perf_counter() - t_start) * 1000.0)
                                    first_sentence = False
                                total_duration_ms += tts_met.t4_audio_duration_ms
                                metrics.engine_used = tts_met.engine_used or tts_met.provider_used
                                continue
                        except VoiceCancelledError:
                            logger.info("[VOICE SPEAKER] Locución cancelada por interrupción del usuario.")
                            break
                        except Exception as e:
                            logger.warning(f"[VOICE TTS] TTSManager falló ({e}), intentando fallback SAPI...")

                        if token.is_cancelled:
                            break

                        # Fallback a SAPI por frase si TTSManager falla
                        try:
                            sp = self._get_sapi_speaker()
                            if sp:
                                t_play_start = time.perf_counter()
                                if first_sentence:
                                    metrics.startup_latency_ms = (t_play_start - t_start) * 1000.0
                                    first_sentence = False
                                sp.Speak(sentence)
                                dur = (time.perf_counter() - t_play_start) * 1000.0
                                total_duration_ms += dur
                                metrics.engine_used = "sapi"
                                continue
                        except Exception:
                            pass

                        # Fallback pyttsx3 por frase
                        try:
                            import pyttsx3

                            engine = pyttsx3.init()
                            engine.setProperty("rate", 175)
                            t_play_start = time.perf_counter()
                            if first_sentence:
                                metrics.startup_latency_ms = (t_play_start - t_start) * 1000.0
                                first_sentence = False
                            engine.say(sentence)
                            engine.runAndWait()
                            engine.stop()
                            total_duration_ms += (time.perf_counter() - t_play_start) * 1000.0
                            metrics.engine_used = "pyttsx3"
                        except Exception as ex3:
                            logger.error(f"[VOICE TTS FATAL] Fallo en todos los motores de voz: {ex3}")
                            break

            # Si se proporciona capture_engine y barge_in_controller, monitorear el micrófono concurrentemente
            # garantizando coordinación única a través de capture_engine._lock (sin doble captura)
            if capture_engine is not None and self.barge_in_controller is not None:
                play_thread = threading.Thread(target=_run_playback, name="TTSPlaybackWorker", daemon=True)
                play_thread.start()

                mic = getattr(capture_engine, "_microphone", None)
                if mic:
                    try:
                        with capture_engine._lock:
                            with mic as source:
                                from services.voice.audio_input import AudioChunk

                                while play_thread.is_alive() and not token.is_cancelled:
                                    try:
                                        buf = source.stream.read(source.CHUNK, exception_on_overflow=False)
                                        if not buf:
                                            break
                                        chunk_obj = AudioChunk(
                                            data=buf,
                                            sample_rate=source.SAMPLE_RATE,
                                            bytes_per_sample=source.SAMPLE_WIDTH,
                                            channels=1,
                                        )
                                        interrupted = self.barge_in_controller.process_audio_chunk(
                                            chunk=chunk_obj,
                                            conversation_active=True,
                                            session_id=session_id,
                                        )
                                        if interrupted:
                                            logger.info("[VOICE SPEAKER] [BARGE-IN ACTIVADO] Audio de JESSYCA interrumpido por habla del usuario.")
                                            break
                                    except Exception as e_stream:
                                        logger.debug(f"[VOICE SPEAKER] Stream de lectura en barge-in finalizado: {e_stream}")
                                        break
                    except Exception as e_mic:
                        logger.debug(f"[VOICE SPEAKER] Monitoreo de micrófono en barge-in no disponible: {e_mic}")

                play_thread.join(timeout=45.0)
            else:
                # Modo síncrono estándar (compatible con CLI básica y tests unitarios)
                _run_playback()

            metrics.duration_ms = total_duration_ms
            return metrics
        finally:
            self._current_token = None
            if self.barge_in_controller:
                self.barge_in_controller.notify_tts_finished()
            if hasattr(self, "aurora_bridge") and self.aurora_bridge:
                try:
                    self.aurora_bridge.notify_tts_end(interrupted=bool(token and token.is_cancelled))
                except Exception:
                    pass


def iniciar_modo_voz(
    show_header: bool = True,
    custom_banner: str | None = None,
    mcp_info: str | None = None,
    ptt_mode: bool = False,
    enable_orb: bool = True,
) -> None:
    """Inicia el bucle interactivo de voz (continua o Pulsar para Hablar / PTT)."""
    if custom_banner:
        print(custom_banner)
    elif show_header:
        print(BANNER_PTT if ptt_mode else BANNER_VOZ)

    settings = get_settings()

    # 1. Diagnóstico e inspección de dispositivos de entrada con AudioDeviceManager (Fase 71)
    device_manager = get_audio_device_manager()
    resolver = VoiceDeviceResolver()
    try:
        selected_desc = device_manager.select_device(validate_signal=True)
        resolved_dev = selected_desc.to_resolved_audio_device()
        speaker = VoiceSpeaker()

        # Log estructurado informativo (Fase 71 - Sección 14)
        val_status = "OK" if selected_desc.signal_status in (SignalValidationStatus.VALID, SignalValidationStatus.SILENT) else selected_desc.signal_status.value
        logger.info(
            f"AUDIO:\n"
            f"selected: {selected_desc.display_name}\n"
            f"runtime_index: {selected_desc.runtime_index}\n"
            f"host_api: {selected_desc.host_api}\n"
            f"input_channels: {selected_desc.max_input_channels}\n"
            f"validation: {val_status}"
        )

        fb_text = " (Fallback por señal)" if resolved_dev.fallback_used else ""
        print(f"  Micrófono: {selected_desc.display_name} [Índice temporal: {selected_desc.runtime_index}]{fb_text}")
        if mcp_info:
            print(f"  MCP: {mcp_info}")
        print(f"  Voz: {speaker.voice_name}")
        # Log estructurado de TTS (Fase 72)
        tts_mgr = get_tts_manager()
        active_tts = tts_mgr.get_active_provider()
        has_fb = bool(
            tts_mgr.fallback_provider_name
            and tts_mgr.fallback_provider_name != tts_mgr.preferred_provider_name
            and tts_mgr.fallback_provider_name.lower() not in ("none", "")
        )
        fb_display = tts_mgr.fallback_provider_name if has_fb else "sin fallback"
        logger.info(
            f"TTS:\n"
            f"preferred: {tts_mgr.preferred_provider_name}\n"
            f"active: {active_tts.name}\n"
            f"fallback: {fb_display}"
        )
        print(f"  TTS Motor: {active_tts.name} (Preferido: {tts_mgr.preferred_provider_name}, Fallback: {fb_display})")
        logger.info(f"[DEMO] Microphone: {resolved_dev.display_name} (Index: {resolved_dev.index})")
        logger.info(f"[DEMO] TTS: {speaker.voice_name}")
    except Exception as e:
        print(f"\n  [ERROR] No se pudo encontrar micrófono de entrada: {e}")
        return

    # 2. Inicialización del proveedor STT y del motor de captura calibrado (Fases 51.1, 51.2 y Prompt 08)
    try:
        stt_provider_name = getattr(settings, "VOICE_STT_PROVIDER", "faster-whisper")
        stt_service = get_stt_service(stt_provider_name)
        print(f"  [Inicializando y verificando STT ({stt_service.name})...]")
        t_w0 = time.perf_counter()
        if hasattr(stt_service, "warmup"):
            stt_service.warmup()
        elif hasattr(stt_service, "load_model"):
            stt_service.load_model()
        t_w1 = time.perf_counter()
        eff_dev = getattr(stt_service, "effective_device", "cpu")
        eff_comp = getattr(stt_service, "effective_compute_type", "default")
        load_time_ms = (t_w1 - t_w0) * 1000.0
        fb_cpu = " (Fallback a CPU por dependencias GPU)" if getattr(stt_service, "is_fallback_cpu_used", False) else ""
        net_desc = "Sí (requiere internet)" if stt_service.requires_network else "No (100% local/offline)"
        print(f"  STT Motor: {stt_service.name} [Dispositivo: {eff_dev.upper()} | Cómputo: {eff_comp} | Warmup: {load_time_ms:.0f}ms]{fb_cpu}")
        logger.info(
            f"[MODO_VOZ] STT verificado y listo: {stt_service.name} "
            f"(device={eff_dev}, compute={eff_comp}, warmup_ms={load_time_ms:.1f}, fallback_cpu={getattr(stt_service, 'is_fallback_cpu_used', False)})"
        )

        capture_engine = CalibratedVoiceCaptureEngine(
            sample_rate=settings.VOICE_SAMPLE_RATE,
            channels=settings.VOICE_CHANNELS,
            pre_roll_ms=settings.VOICE_PRE_ROLL_MS,
            post_roll_ms=settings.VOICE_POST_ROLL_MS,
            min_speech_ms=settings.VOICE_MIN_SPEECH_MS,
            max_capture_ms=settings.VOICE_MAX_CAPTURE_MS,
            silence_timeout_ms=settings.VOICE_SILENCE_TIMEOUT_MS,
            confidence_threshold=settings.VOICE_STT_CONFIDENCE_THRESHOLD,
            language=settings.VOICE_STT_LANGUAGE,
            device_index=resolved_dev.index,
            device_resolver=resolver,
            resolved_device=resolved_dev,
            adaptive_eos_enabled=settings.VOICE_ADAPTIVE_EOS_ENABLED,
            stt_service=stt_service,
        )
        print(f"  [Calibrando micrófono ({resolved_dev.display_name}) para ruido ambiente...]")
        calib_res = capture_engine.calibrate_ambient_noise(duration_sec=settings.VOICE_CALIBRATION_DURATION_SEC)
        print(f"  [Calibración completada | Ruido base: {calib_res.noise_floor_rms:.1f} RMS | Umbral VAD: {calib_res.recommended_start_threshold:.1f}]")
    except Exception as e:
        print(f"\n  [ERROR] No se pudo inicializar el micrófono o STT: {e}")
        print("  Verifica que tu micrófono esté conectado y habilitado.")
        return

    agent = JessycaLocalAgent.get_instance()
    session_id = f"voice_interactive_{int(time.time())}"
    voice_session = ContinuousVoiceSession(
        session_id=session_id,
        conversation_idle_timeout=10.0,
    )
    state_machine = StateMachine(follow_up_window=10.0)
    stt_event_adapter = STTEventAdapter(stt_service=stt_service, state_machine=state_machine)
    barge_in_controller = BargeInController(
        tts_manager=tts_mgr,
        state_machine=state_machine,
        vad_service=capture_engine.vad_service,
    )
    speaker.barge_in_controller = barge_in_controller

    # Inicializar Orbe 3D Aurora si está habilitado
    aurora_runtime: Any | None = None
    aurora_bridge: Any | None = None
    if enable_orb:
        try:
            from interfaces.aurora.runtime import AuroraRuntime
            aurora_runtime = AuroraRuntime(headless=False)
            aurora_runtime.start()
            aurora_bridge = aurora_runtime.bridge
            agent.aurora_bridge = aurora_bridge
            aurora_bridge.attach_state_machine(state_machine)
            speaker.aurora_bridge = aurora_bridge
            print("  [✓] JESSYCA ORB 4.0: Núcleo Aurora 3D & Fusión Reactiva en ejecución")
        except Exception as e_orb:
            logger.warning(f"[MODO_VOZ] No se pudo lanzar el Orbe Aurora: {e_orb}")


    saludo = "Hola, soy Jessyca. Di 'Jessica' seguido de tu orden, o habla directamente."
    print(f"\n  Jessyca: {saludo}\n")
    speaker.speak(saludo, session_id=session_id)

    consecutive_empty_count = 0
    last_spoken_text = saludo
    last_spoken_time = time.perf_counter()

    def _is_acoustic_echo(captured_text: str, spoken_text: str, elapsed_sec: float) -> bool:
        if not spoken_text or not captured_text or elapsed_sec > 5.0:
            return False
        import re

        c_clean = re.sub(r"\b(jessica|jessyca)\b", "", captured_text.lower()).strip()
        s_clean = re.sub(r"\b(jessica|jessyca)\b", "", spoken_text.lower()).strip()
        if len(c_clean) > 8 and c_clean in s_clean:
            return True
        c_words = set(re.findall(r"\w+", c_clean))
        s_words = set(re.findall(r"\w+", s_clean))
        if not c_words or not s_words:
            return False
        overlap = len(c_words.intersection(s_words)) / len(c_words)
        return overlap >= 0.55

    try:
        while True:
            try:
                # En modo Pulsar para Hablar (PTT), esperar activación explícita del usuario
                if ptt_mode:
                    try:
                        user_prompt = input("\n  [🎤 PULSAR PARA HABLAR: Presiona ENTER para grabar tu orden (o escribe 'salir')] > ")
                        if user_prompt.strip().lower() in ("salir", "exit", "quit", "q", "adios", "adiós"):
                            despedida = "¡Hasta luego! Modo voz detenido."
                            print(f"\n  Jessyca: {despedida}\n")
                            speaker.speak(despedida)
                            voice_session.end_session()
                            break
                    except (EOFError, KeyboardInterrupt):
                        break
                    print("  [🔴 Grabando audio bajo demanda... Habla ahora]")
                    capture_mode_str = VoiceSessionMode.CONVERSATION_ACTIVE.value
                else:
                    # Comprobar expiración por inactividad
                    voice_session.check_timeout()
                    if voice_session.mode in (VoiceSessionMode.CONVERSATION_ACTIVE, VoiceSessionMode.WAITING_FOR_FOLLOWUP):
                        print(f"\n  [Conversación Continua Activa — Turno {voice_session.turns_count + 1} | Habla directamente...]")
                    else:
                        print("\n  [En espera de 'Jessica' | Habla ahora...]")
                    capture_mode_str = voice_session.mode.value

                logger.info(f"[VOICE_CAPTURE_STARTED] Modo: {capture_mode_str}...")
                t_capture_start = time.perf_counter()

                def _on_listening() -> None:
                    if state_machine.current_state == SessionState.IDLE:
                        state_machine.transition_to(SessionState.WAKEWORD)
                        state_machine.transition_to(SessionState.LISTENING)
                    elif state_machine.current_state != SessionState.LISTENING:
                        state_machine.transition_to(SessionState.LISTENING)

                def _on_transcribing() -> None:
                    if state_machine.current_state == SessionState.LISTENING:
                        state_machine.transition_to(SessionState.TRANSCRIBING)

                capture_result = capture_engine.capture_and_transcribe(
                    mode=capture_mode_str,
                    timeout=7.0,
                    on_listening_start=_on_listening,
                    on_transcribing_start=_on_transcribing,
                    on_audio_chunk=aurora_bridge.on_pcm_chunk if aurora_bridge else None,
                )
                stt_latency_ms = (time.perf_counter() - t_capture_start) * 1000.0
                logger.info(f"[VOICE_CAPTURE_STOPPED] Captura finalizada. Descarte: {capture_result.discard_reason.value}")

                # 3. Manejo de silencios normales en espera
                if capture_result.discard_reason == VoiceDiscardReason.NO_AUDIO:
                    stt_event_adapter.process_transcript("")
                    consecutive_empty_count += 1
                    if consecutive_empty_count >= settings.VOICE_MAX_EMPTY_RETRIES:
                        if voice_session.mode != VoiceSessionMode.IDLE:
                            print("  [No se detectó actividad. Sesión en pausa hasta tu próxima llamada.]")
                        consecutive_empty_count = 0
                    continue

                # 4. Manejo de fallos con feedback diferenciado
                if not capture_result.is_success:
                    stt_event_adapter.process_transcript("")
                    consecutive_empty_count += 1
                    if capture_result.user_feedback_message:
                        print(f"  {capture_result.user_feedback_message}")
                    continue

                # 5. Captura exitosa
                consecutive_empty_count = 0
                texto = capture_result.text

                # 5.1 Descarte de eco acústico del altavoz en conversación continua
                elapsed_since_speech = time.perf_counter() - last_spoken_time
                if (
                    voice_session.mode in (VoiceSessionMode.CONVERSATION_ACTIVE, VoiceSessionMode.WAITING_FOR_FOLLOWUP)
                    and _is_acoustic_echo(texto, last_spoken_text, elapsed_since_speech)
                ):
                    logger.warning(
                        f"[VOICE_ECHO_DETECTED] Descartando eco acústico de la voz del asistente: '{texto}' "
                        f"(último mensaje: '{last_spoken_text}' hace {elapsed_since_speech:.2f}s)"
                    )
                    print(f"  [Eco acústico del altavoz detectado y descartado: '{texto}']")
                    continue

                # Emitir evento UtteranceFinal y actualizar State Machine (Fase 67)
                stt_event_adapter.process_transcript(texto, confidence=capture_result.confidence)
                logger.info(f"[VOICE_TRANSCRIPT] Texto reconocido: '{texto}' (Confianza: {capture_result.confidence:.2f})")
                print(f"\n  Tú (Voz): {texto}")


                # Comando de salida
                if texto.lower() in ("salir", "exit", "quit", "adios", "adiós", "terminar", "apágate", "cerrar"):
                    despedida = "¡Hasta luego! Que tengas un excelente día."
                    print(f"\n  Jessyca: {despedida}\n")
                    speaker.speak(despedida)
                    voice_session.end_session()
                    break

                print("  [Procesando con Agente Core...]")
                logger.info(f"[VOICE_EXECUTION_STARTED] Procesando petición de voz: '{texto}'")

                if aurora_bridge:
                    aurora_bridge.notify_cognition("routing")

                voice_session.on_processing_started()

                # Procesamiento con Agente Local JESSYCA
                t_interact_start = time.perf_counter()
                req = JessycaRequest(
                    session_id=session_id,
                    user_input=texto,
                    modality=InputModality.VOICE,
                    metadata={
                        "stt_confidence": capture_result.confidence,
                        "original_transcript": texto,
                    },
                )
                res = agent.interact(req)
                _agent_latency_ms = (time.perf_counter() - t_interact_start) * 1000.0

                logger.info(f"[VOICE_EXECUTION_COMPLETED] Estado: {res.status.value}, Intent: {res.intent}, Skill: {res.selected_skill}")

                voice_session.on_speaking_started()
                print("  [Sintetizando y respondiendo con voz...]")
                t_tts_start = time.perf_counter()

                if res.requires_clarification or res.status.value == "AWAITING_CLARIFICATION":
                    msg = res.clarification_question or res.spoken_text or res.response_text or "¿Podrías aclararme qué deseas hacer?"
                    if res.proposed_interpretation:
                        print(f"  [Aclaración detectada | Transcripción: '{texto}' | Interpretación propuesta: '{res.proposed_interpretation}']")
                    print(f"\n  Jessyca (Aclaración): {msg}")
                    tts_metrics = speaker.speak(msg, session_id=session_id, capture_engine=capture_engine)
                elif res.requires_confirmation:
                    msg = f"Atención: {res.response_text}. ¿Deseas autorizar esta acción?"
                    print(f"\n  Jessyca (Confirmación): {msg}")
                    tts_metrics = speaker.speak(msg, session_id=session_id, capture_engine=capture_engine)
                else:
                    msg = res.spoken_text or res.response_text
                    print(f"\n  Jessyca: {msg}")
                    tts_metrics = speaker.speak(msg, session_id=session_id, capture_engine=capture_engine)

                t_turn_end = time.perf_counter()
                last_spoken_text = msg or ""
                last_spoken_time = t_turn_end
                voice_session.on_speaking_finished()

                # Medición y registro formal de latencias estructuradas (Fase 75.2-B)
                t_eos_ref = capture_result.eos_timestamp or (t_capture_start + 1.0)
                eos_to_stt_val = capture_result.eos_to_stt_start_ms
                stt_dur_val = capture_result.stt_duration_ms or stt_latency_ms
                stt_to_intent_val = max(0.0, (t_interact_start - (t_capture_start + (stt_latency_ms / 1000.0))) * 1000.0)
                intent_dur_val = res.metrics.intent_latency_ms
                llm_dur_val = res.metrics.model_inference_latency_ms
                intent_to_exec_val = res.metrics.execution_latency_ms
                tts_dur_val = tts_metrics.duration_ms if tts_metrics else 0.0
                tts_startup_val = tts_metrics.startup_latency_ms if tts_metrics else 0.0
                audio_start_val = max(0.0, (t_tts_start + (tts_startup_val / 1000.0) - t_eos_ref) * 1000.0)
                total_turn_ms = max(0.0, (t_turn_end - t_eos_ref) * 1000.0)

                lat_trace = UtteranceLatencyTrace(
                    utterance_id=capture_result.diagnostic.capture_id,
                    eos_to_stt_start=eos_to_stt_val,
                    stt_duration=stt_dur_val,
                    stt_to_intent=stt_to_intent_val,
                    intent_duration=intent_dur_val,
                    llm_duration=llm_dur_val,
                    intent_to_execution=intent_to_exec_val,
                    tts_duration=tts_dur_val,
                    audio_start=audio_start_val,
                    total_response_time=total_turn_ms,
                )
                formatted_trace = lat_trace.format_trace()
                logger.info(f"\n{formatted_trace}")
                print(f"\n{formatted_trace}\n")

                # Hitos canónicos de tiempo (fin de voz, fin de STT, respuesta del Core, primer audio reproducido, fin de reproducción)
                t_first_audio_ms = (t_tts_start + (tts_startup_val / 1000.0) - t_eos_ref) * 1000.0
                t_core_resp_ms = (t_interact_start + (_agent_latency_ms / 1000.0) - t_eos_ref) * 1000.0
                logger.info(
                    f"[TIMELINE MILESTONES] "
                    f"1. Fin de voz (EOS): 0.0ms | "
                    f"2. Fin de STT: +{stt_dur_val:.1f}ms | "
                    f"3. Respuesta del Core: +{t_core_resp_ms:.1f}ms (Core dur: {_agent_latency_ms:.1f}ms) | "
                    f"4. Primer audio reproducido: +{t_first_audio_ms:.1f}ms (TTS inicio: {tts_startup_val:.1f}ms) | "
                    f"5. Fin de reproducción: +{total_turn_ms:.1f}ms (TTS dur: {tts_dur_val:.1f}ms)"
                )

                # Breve pausa de estabilización de audio para evitar que el micrófono capture el eco del altavoz
                time.sleep(0.3)

                if os.getenv("VOICE_DEBUG", "").lower() in ("1", "true", "yes"):
                    print(f"  [DEBUG | Intent: {res.intent} | Agent: {res.selected_agent} | Skill: {res.selected_skill} | Estado: {res.status.value} | Latencia: {res.metrics.total_latency_ms:.1f}ms]")

            except (KeyboardInterrupt, EOFError):
                despedida = "¡Hasta luego! Modo voz detenido."
                print(f"\n\n  Jessyca: {despedida}\n")
                speaker.speak(despedida)
                voice_session.end_session()
                break
            except (VoiceCancelledError, VoiceInterruptedError) as vce:
                logger.info(f"[MODO VOZ] Interrupción o cancelación del turno: {vce}")
                continue
            except Exception as e:
                logger.error(f"[MODO VOZ] Error en el ciclo de interacción: {e}")
                print(f"  [Error inesperado: {e}]")
    finally:
        if getattr(agent, "aurora_bridge", None) is aurora_bridge:
            agent.aurora_bridge = None
        if aurora_runtime:
            try:
                aurora_runtime.stop()
            except Exception as e_orb_stop:
                logger.debug(f"[MODO VOZ CLEANUP] Error al detener Orbe Aurora: {e_orb_stop}")
        try:
            from core.browser_session_manager import reset_shared_browser_adapter
            reset_shared_browser_adapter()
        except Exception as e_br:
            logger.debug(f"[MODO VOZ CLEANUP] Error al cerrar adaptador Playwright: {e_br}")


if __name__ == "__main__":
    iniciar_modo_voz()
