"""Administrador de resolución y selección de modelos LLM (ModelManager - Fase 1: Multi-LLM Foundation).

Actúa como capa intermedia desacoplada entre el Core de Jessyca y el ModelRegistry.
Responsabilidad:
  - Resolver el modelo configurado o solicitado explícitamente.
  - Administrar el modelo predeterminado del sistema.
  - Consultar capacidades descriptivas sin acoplamiento a librerías de inferencia.
"""

from __future__ import annotations

import os
import threading
from typing import Any, ClassVar

from core.llm.exceptions import ModelNotFoundError
from core.llm.model_profile import ModelProfile
from core.llm.model_registry import ModelRegistry
from core.logger import get_logger

logger = get_logger("jessyca.llm.manager")

# Modelo principal y de respaldo predeterminados del sistema (Fase 1: Consolidado)
PRIMARY_DEFAULT_MODEL = "qwen3.5:9b"
FALLBACK_DEFAULT_MODEL = "gemma4:e4b"

# Marcador semántico de selección automática: nunca registrar en ModelRegistry
AUTO_ROUTE_MODEL = "auto-routed"


class ModelManager:
    """Administrador de selección explícita y resolución de perfiles de modelos LLM."""

    _instance: ClassVar[ModelManager | None] = None
    _class_lock: ClassVar[threading.RLock] = threading.RLock()

    def __init__(
        self,
        registry: ModelRegistry | None = None,
        default_model_name: str | None = None,
        router: Any | None = None,
    ) -> None:
        self._lock = threading.RLock()
        self._registry = registry or ModelRegistry.get_instance()
        self._router = router
        # Resolución inicial del modelo por defecto (prioridad: argumento -> variable de entorno -> models_config.json -> PRIMARY_DEFAULT_MODEL)
        env_model = os.getenv("OLLAMA_MODEL")
        if default_model_name:
            initial_default = default_model_name
        elif env_model:
            initial_default = env_model
        else:
            initial_default = PRIMARY_DEFAULT_MODEL
            try:
                from pathlib import Path
                import json
                cfg_file = Path("config/models_config.json")
                if cfg_file.exists():
                    with open(cfg_file, "r", encoding="utf-8") as f:
                        cfg_data = json.load(f)
                        if "active_model" in cfg_data:
                            initial_default = cfg_data["active_model"]
            except Exception:
                pass
        self._default_model_name = str(initial_default).strip()

    @classmethod
    def get_instance(cls) -> ModelManager:
        """Obtiene la instancia singleton global del gestor de modelos."""
        with cls._class_lock:
            if cls._instance is None:
                cls._instance = ModelManager()
            return cls._instance

    @property
    def registry(self) -> ModelRegistry:
        """Acceso de solo lectura al registro de modelos."""
        return self._registry

    def get_model(self, name: str | None = None, context: Any | None = None) -> ModelProfile:
        """Resuelve y obtiene el ModelProfile solicitado o el modelo predeterminado si name es None.

        Si se solicita explícitamente el marcador semántico AUTO_ROUTE_MODEL ('auto-routed'),
        delega la selección dinámicamente al ModelRouter mediante RoutingPolicy.
        En caso de fallo en el router o indisponibilidad, activa automáticamente un
        fallback seguro al modelo predeterminado del sistema.
        """
        with self._lock:
            stripped = name.strip() if name and name.strip() else ""
            if not stripped:
                # Resolución directa al modelo predeterminado sin invocar el router
                target_name = self._default_model_name
            elif stripped == AUTO_ROUTE_MODEL:
                # Delegación explícita a ModelRouter
                try:
                    from core.llm.model_router import ModelRouter
                    from core.llm.routing_policy import RoutingContext

                    active_router = self._router or ModelRouter.get_instance()
                    ctx = context if isinstance(context, RoutingContext) else RoutingContext()
                    routed_profile = active_router.route(ctx)
                    logger.info(
                        f"[MODEL MANAGER] Auto-route resuelto dinámicamente por ModelRouter: '{routed_profile.name}' "
                        f"(provider: {routed_profile.provider})"
                    )
                    return routed_profile
                except Exception as ex:
                    logger.warning(
                        f"[MODEL MANAGER] Error durante delegación auto-route a ModelRouter ({ex}). "
                        f"Activando fallback seguro al modelo predeterminado: '{self._default_model_name}'"
                    )
                    target_name = self._default_model_name
            else:
                target_name = stripped

            try:
                profile = self._registry.get(target_name)
                logger.debug(f"[MODEL MANAGER] Modelo resuelto: '{profile.name}'")
                return profile
            except ModelNotFoundError:
                logger.error(
                    f"[MODEL MANAGER] El modelo '{target_name}' no se encuentra en el registro."
                )
                raise

    def set_default_model(self, name: str) -> None:
        """Establece el modelo predeterminado del sistema validando previamente su existencia en el catálogo."""
        with self._lock:
            clean_name = name.strip()
            if not self._registry.exists(clean_name):
                raise ModelNotFoundError(
                    model_name=clean_name,
                    details={"error": "No se puede establecer como predeterminado un modelo no registrado."},
                )
            self._default_model_name = clean_name
            logger.info(f"[MODEL MANAGER] Modelo predeterminado establecido a: '{clean_name}'")

    def get_default_model_name(self) -> str:
        """Retorna el identificador del modelo predeterminado actual."""
        with self._lock:
            return self._default_model_name

    def list_available_models(self) -> list[ModelProfile]:
        """Lista todos los perfiles de modelos disponibles en el catálogo."""
        return self._registry.list_models()

    def is_model_available(self, name: str) -> bool:
        """Comprueba si un modelo específico se encuentra registrado."""
        return self._registry.exists(name)


def get_model_manager() -> ModelManager:
    """Función de acceso directo a la instancia global de ModelManager."""
    return ModelManager.get_instance()
